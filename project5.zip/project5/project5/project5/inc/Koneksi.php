<?php

namespace Inc;

use PDO;
use PDOException;

class Koneksi
{
    protected object $koneksi;

    public function __construct()
    {
        try {
            $this->koneksi = new PDO(
                "mysql:host=localhost;dbname=dbakademik;charset=utf8mb4",
                "root",
                ""
            );

            $this->koneksi->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

        } catch (PDOException $e) {
            echo "Koneksi gagal: " . $e->getMessage();
        }
    }
}