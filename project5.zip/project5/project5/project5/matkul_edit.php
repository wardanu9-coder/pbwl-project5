<?php

require_once "inc/Koneksi.php";
require_once "app/Matakuliah.php";

$matkul = new App\Matakuliah();
$row = $matkul->edit($_GET['id']);

?>

<h2 class="fw-bold mb-3">Edit Matakuliah</h2>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">

                <form action="matkul_proses.php?action=update" method="post">

                    <input type="hidden" name="matkul_id" value="<?php echo $row['matkul_id']; ?>">

                    <div class="mb-3">
                        <label class="form-label">Kode Matakuliah</label>
                        <input type="text" class="form-control" name="matkul_kode" value="<?php echo $row['matkul_kode']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nama Matakuliah</label>
                        <input type="text" class="form-control" name="matkul_nama" value="<?php echo $row['matkul_nama']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">SKS</label>
                        <input type="number" class="form-control" name="matkul_sks" value="<?php echo $row['matkul_sks']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Semester</label>
                        <input type="number" class="form-control" name="matkul_semester" value="<?php echo $row['matkul_semester']; ?>" required>
                    </div>

                    <button type="submit" name="update" class="btn btn-primary">Update</button>

                    <a href="index.php?page=matkul" class="btn btn-secondary">Batal</a>

                </form>

            </div>
        </div>
    </div>
</div>